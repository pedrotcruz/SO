#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº: 99379   Nome: Pedro Cruz
## Nome do Módulo: faturacao.sh
## Descrição/Explicação do Módulo: Cria as faturas dos clientes, estando estas
## organizadas por ordem segundo o ficheiro pessoas.txt
##
###############################################################################

if [ ! -f relatorio_utilizacao.txt ]; then
  ./error 1 "relatorio_utilizacao.txt"
  exit 1
fi

if [ -f faturas.txt ]; then
  rm faturas.txt
fi

if [ -n relatorio_utilizacao.txt ]; then
touch faturas.txt
fi

i=1
linhas=$(cat ralatorio_utilizacao.txt | wc -l)
while [ $i -le $linhas ]; do

IDrelatorio=$(cat relatorio_utilizacao.txt | cut -d ':' -f3 | head -$i | tail -1)

IDpessoas=ID$(cat pessoas.txt | cut -d ':' -f3 | head -$i | tail -1)

i=$(($i+1))
done


i=1
linhas=$(((cat relatorio_utilizacao.txt | wc -l) *3 ))
while [ $i -le $linhas ]; do

echo Cliente:$(cat pessoas.txt | cut -d ':' -f2 | head -$i | tail -1)
if [ IDrelatorio=IDpessoas ]; then
echo $(cat relatorio_utilizacao.txt | head -$i | tail -1) >> faturas.txt
fi
done