#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº: 99379    Nome: Pedro Cruz
## Nome do Módulo: menu.sh
## Descrição/Explicação do Módulo: Este módulo é dedicado à acessibilidade, de forma a ser facilmente
## abordado por um trabalhador. Permite facilmente executar os scrips feitos anteriormente
##
###############################################################################

BREAK1=1;
while [[ "$BREAK1" -eq 1 ]]; do
    echo "1. Listar condutores"
    echo "2. Altera taxa de portagem"
    echo "3. Stats"
    echo "4. Faturação"
    echo "0. Sair"
    echo "Opçao:  "
    read  opcao 
    if [[ "$opcao" = 1 ]]; then
        ./lista_condutores.sh
    fi
    if [[ "$opcao" = "2" ]]; then
        echo "Lanço: " 
        read lanco
        echo "Auto-estrada: "
        read estrada
        echo "Novo Valor taxa : "
        read taxa
        ./altera_taxa_portagem.sh $lanco $estrada $taxa
    fi
    if [[ "$opcao" = "3" ]]; then
        echo "Stats"
        echo "1.Nome de todas as autoestradas"
        echo "2.Registos de utilizaçao"
        echo "3.Listagem de condutores"
        echo "0.Voltar"
        echo ": "
        read decisao
        if [[ "$decisao" = "1" ]]; then
             ./stats.sh "listar"
        fi
        if [[ "$decisao" = "2" ]]; then
            echo "Mínimo de registos: "
            read registos
            ./stats.sh "registos" $registos
        fi
        if [[ "$decisao" = "3" ]]; then
            ./stats.sh "condutores"
        fi
        if [[ "$decisao" = "0" ]]; then
            BREAK1=1
        fi
    fi
    if [[ "$opcao" = "4" ]]; then
        ./faturacao.sh
    fi
    if [[ "$opcao" = "0" ]]; then
        BREAK1=$(($BREAK1+1))
    fi
    if ! [[ "$opcao" =~ ^[0-4]+$ ]];then
        ./error 3 "$opcao"
    fi
done