#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº: 99379    Nome: Pedro Cruz 
## Nome do Módulo: lista_condutores.sh
## Descrição/Explicação do Módulo: Converte o ficheiro pessoas.txt na lista de condutores
## conforme consta no enunciado
##
###############################################################################

if [ -f condutores.txt ]; then
  rm condutores.txt
fi


if [ ! -f pessoas.txt ]; then
  ./error 1 "pessoas.txt"
else

i=1

linhas=$(cat pessoas.txt | wc -l)
while [ $i -le $linhas ]; do


carta=$(cat pessoas.txt | cut -d ':' -f1 | head -$i | tail -1)

nome=$(cat pessoas.txt | cut -d ':' -f2 | head -$i | tail -1)

ID=$(cat pessoas.txt | cut -d ':' -f3 | head -$i | tail -1)

contacto=$(cat pessoas.txt | cut -d ':' -f4 | head -$i | tail -1)

saldo=150

echo "ID$ID-$nome;$carta;$contacto;$ID;$saldo" >> condutores.txt

i=$(($i+1))
done
./success 2 "condutores.txt"
fi