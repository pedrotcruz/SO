#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº: 99379  Nome: Pedro Cruz
## Nome do Módulo: stats.sh
## Descrição/Explicação do Módulo: Este script é executado para obter informações sobre o sistema
##
##
###############################################################################

if (( $#>2 )); then
    ./error 2
    exit 0
else
    if [ -z $1 ]; then
        ./error 3 $1 
        exit 0
    fi
fi
case $1 in 
    "condutores") 
    IDs=$(cat relatorio_utilizacao.txt | cut -d ":" -f 3 | sort -r -k 3 -n | uniq);
    nrIDs=$(echo "$IDs" | wc -l);
    i=0
    touch nomes.txt
    while [ $i -ltnr ] 
    do
        ID=$(echo "$IDs" | head -$(($i+1)) | tail -1);
        NOME=$(cat condutores.txt | grep "$ID" | cut -d ";" -f 1 | cut -d "-" -f 2);
        echo "$NOME" >> nomes.txt
        i=$(($i+1))
    done
    ./success 6 nomes.txt
    echo ""
    rm nomes.txt;;
    "listar") echo ""; cat portagens.txt | cut -d ":" -f 3 | sort | uniq > estradas.txt; ./success 6 estradas.txt; rm estradas.txt; echo "";;
    "registos") 
    echo ""
    if (( $#!= 2 )); then
        ./error 2
        exit 0
    fi
    if (( $2 < 0 )); then
        ./error 3 $2
        exit 0
    fi

    lancos=$(cat relatorio_utilizacao.txt | cut -d ":" -f 2 | sort | uniq);

    nrlancos1=$(cat relatorio_utilizacao.txt | cut -d ":" -f 2 | sort | uniq | wc -l);

    nrlancos2=$(cat relatorio_utilizacao.txt | wc -l);

    i=0

    touch   lanco.txt
    
    ./success 6 lanco.txt
    echo ""
    rm  lanco.txt;;