#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2021/2022
##
## Aluno: Nº: 99379  Nome: Pedro Cruz
## Nome do Módulo: altera_taxa_portagem.sh
## Descrição/Explicação do Módulo: Altera a taxa de uma portagem já existente ou, caso não exista, cria
## uma nova com os argumentos dados
##
###############################################################################

lanco=$1
autoestrada=$2
novovalor=$3

#Validar os argumentos passados, avaliando se são em número suficiente
if [ $# != 3 ]; then
./error 2
exit 1
fi

#valor inteiro positivo
if [ $novovalor =~ ^[0-9]+$ ]; then
./error 3 "novo valor da taxa"
exit 1
fi

#lanco
if [ $lanco =~ [a-z/A-Z/-]+$ ]; then
./error 3 "lanço"
exit 1
fi

PONTOS=":"

if [ -f "portagens.txt" ]; then
    i=1
    linhas=$(cat "portagens.txt" | wc -l);
    a=0
    aux=$(cat portagens.txt | cut -d ":" -f 1 | sort -n | uniq | head -$linhas | tail -1);
    ID=$(($aux+1));
    while [ $i -le $linhas ]; do
        lanco=$(cat "portagens.txt" | cut -d ":" -f 2 | head -$i | tail -1);
        if ! [[ "$lanco" = "$1" ]]; then
            a=$(($a+1))
        fi
    i=$(($i+1))
done

if [[ $a = $linhas ]]; then
        echo "$ID$PONTOS$1$PONTOS$2$PONTOS$3" >> "portagens.txt"
        ./success 3 $1
    else
 
    j=0
    while [ $j -le $linhas ]; do
        lanco2=$(cat portagens.txt | cut -d ":" -f 2 | head -$j | tail -1);
        taxa=$(cat portagens.txt | cut -d ":" -f 4 | head -$j | tail -1);
        if [[ "$lanco2" = "$1" ]]; then
            sed -i ""$j"s/\(.*\)"$taxa"/\1"$3"/" "portagens.txt"
        fi
    j=$(($j+1))
    done
    ./success 3 $1
    fi
else #portagens.txt nao existir
    touch portagens.txt
    ID=1
    echo "$ID$PONTOS$1$PONTOS$2$PONTOS$3" > "portagens.txt"
    ./success 3 $1
fi

final = $(cat portagens.txt | sort -t ':' -k3,3 -k2,2);
echo "$final" > portagens.txt
./success 4 "portagens.txt"